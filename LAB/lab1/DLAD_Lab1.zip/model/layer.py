import numpy as np

## by yourself .Finish your own NN framework
## Just an example.You can alter sample code anywhere. 


class _Layer(object):
    def __init__(self):
        pass

    def forward(self, *input):
        r"""Define the forward propagation of this layer.

        Should be overridden by all subclasses.
        """
        raise NotImplementedError

    def backward(self, *output_grad):
        r"""Define the backward propagation of this layer.

        Should be overridden by all subclasses.
        """
        raise NotImplementedError
        
## by yourself .Finish your own NN framework
class FullyConnected(_Layer):
    def __init__(self, in_features, out_features):
        self.weight = np.random.randn(in_features, out_features) * 0.01
        self.bias = np.zeros((1, out_features))

        self.weight_grad = 
        self.bias_grad = 

    def forward(self, input):
        

        return output

    def backward(self, output_grad):
        input_grad = 
        self.weight_grad = 
        self.bias_grad = 

        return input_grad

## by yourself .Finish your own NN framework
class ACTIVITY1(_Layer):
    def __init__(self):
        pass

    def forward(self, input):
        

        

        return output

    def backward(self, ):
        
        

        return 

class SoftmaxWithloss(_Layer):
    def __init__(self):
        pass

    def forward(self, input, target):
        

        '''Softmax'''
        

        

        '''Average loss'''
        

        return predict, your_loss

    def backward(self):
        input_grad 

        return input_grad
    
    