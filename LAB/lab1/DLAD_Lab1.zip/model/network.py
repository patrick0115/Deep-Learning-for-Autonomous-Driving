from .layer import *

class Network(object):
    def __init__(self):

        ## by yourself .Finish your own NN framework
        ## Just an example.You can alter sample code anywhere. 
        self.fc1 = FullyConnected(28*28, 60) ## Just an example.You can alter sample code anywhere. 
        self.act1 = 
        self.loss



    def forward(self, input, target):
        h1 = self.fc1.forward(input)
        ## by yourself .Finish your own NN framework
        
        pred, loss = 

        return pred, loss

    def backward(self):
        ## by yourself .Finish your own NN framework
        h1_grad = 
        _ = self.fc1.backward(h1_grad)

    def update(self, lr):
        ## by yourself .Finish your own NN framework
        
        self.fc1.weight -= 
        self.fc1.bias -= 
        
        
